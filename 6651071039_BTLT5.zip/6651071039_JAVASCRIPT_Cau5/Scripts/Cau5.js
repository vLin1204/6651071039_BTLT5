// 1. Nhận dữ liệu nhập vào từ hộp thoại Prompt
let input = prompt("Nhập vào một số nguyên dương:");
let n = parseInt(input);

// Hàm kiểm tra số nguyên tố
function isPrime(num) {
    if (isNaN(num) || num <= 1) {
        return false; // Số nhỏ hơn hoặc bằng 1 không phải là số nguyên tố
    }
    // Lặp từ 2 đến căn bậc hai của num
    for (let i = 2; i <= Math.sqrt(num); i++) {
        if (num % i === 0) {
            return false; // Chia hết cho số khác -> Không phải số nguyên tố
        }
    }
    return true;
}

let resultText = "";

if (isNaN(n) || n <= 0) {
    resultText = "Vui lòng nhập một số nguyên dương hợp lệ!";
} else if (isPrime(n)) {
    resultText = n + " LÀ số nguyên tố.";
} else {
    resultText = n + " KHÔNG PHẢI là số nguyên tố.";
}

// 2. Xuất kết quả ra hộp thoại Alert của trình duyệt
alert(resultText);

// 3. Xuất kết quả ra Console và màn hình trang web
console.log(resultText);
document.getElementById("KetQua").innerText = resultText;