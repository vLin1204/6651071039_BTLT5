let resultList = [];

// Duyệt các số từ 1 đến 99
for (let i = 1; i < 100; i++) {
    // Kiểm tra số lẻ (chia 2 dư 1) và KHÔNG thuộc danh sách (5, 7, 93)
    if (i % 2 !== 0 && i !== 5 && i !== 7 && i !== 93) {
        resultList.push(i);
    }
}

// Chuyển mảng thành chuỗi phân tách bởi dấu phẩy
let resultText = resultList.join(", ");

// 1. Xuất ra Tab Console (F12)
console.log("Danh sách số lẻ:", resultText);

// 2. Xuất ra Hộp thoại alert
alert("Danh sách số lẻ: " + resultText);

// 3. Xuất ra Giao diện trang web (Khớp id KetQua trong HTML)
document.getElementById("KetQua").innerText = resultText;