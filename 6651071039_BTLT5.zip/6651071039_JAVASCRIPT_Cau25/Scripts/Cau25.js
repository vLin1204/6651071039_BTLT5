// Bảng giá chi tiết theo đề bài
const priceList = {
    "Bun bo": 20000,
    "Hu tieu": 18000,
    "Banh canh": 17000,
    "Pho bo": 19000,
    "Nuoi": 15000,
    "Banh mi thit": 12000,
    "Banh cuon": 15000,
    "Ca phe da": 12000,
    "Ca phe sua da": 15000,
    "Chanh day": 13000,
    "Chanh muoi": 12000,
    "Xi muoi": 14000,
    "Sua tuoi": 13000,
    "Cam vat": 17000
};

// Tên hiển thị tương ứng
const nameList = {
    "Bun bo": "Bún bò",
    "Hu tieu": "Hủ tiểu",
    "Banh canh": "Bánh canh",
    "Pho bo": "Phở bò",
    "Nuoi": "Nuôi",
    "Banh mi thit": "Bánh mì thịt",
    "Banh cuon": "Bánh cuốn",
    "Ca phe da": "Cà phê đá",
    "Ca phe sua da": "Cà phê sữa đá",
    "Chanh day": "Chanh dây",
    "Chanh muoi": "Chanh muối",
    "Xi muoi": "Xí muội",
    "Sua tuoi": "Sữa tươi",
    "Cam vat": "Cam vắt"
};

function tinhTien() {
    let thucAnSelect = document.getElementById("thucAn");
    let nuocUongSelect = document.getElementById("nuocUong");
    let thoiDiemRadios = document.getElementsByName("thoiDiem");
    
    let selectedItems = [];
    let subTotal = 0;

    // Lấy các mục thức ăn được chọn (giữ Ctrl để chọn nhiều mục)
    for (let option of thucAnSelect.selectedOptions) {
        let key = option.value;
        selectedItems.push({ name: nameList[key], price: priceList[key] });
        subTotal += priceList[key];
    }

    // Lấy các mục nước uống được chọn
    for (let option of nuocUongSelect.selectedOptions) {
        let key = option.value;
        selectedItems.push({ name: nameList[key], price: priceList[key] });
        subTotal += priceList[key];
    }

    if (selectedItems.length === 0) {
        alert("Vui lòng chọn ít nhất một món ăn hoặc nước uống!");
        return;
    }

    // Kiểm tra thời điểm (Ban ngày hay Ban đêm)
    let isNight = false;
    for (let radio of thoiDiemRadios) {
        if (radio.checked && radio.value === "banDem") {
            isNight = true;
            break;
        }
    }

    // Nếu ban đêm thì cộng thêm 10% tổng tiền
    let grandTotal = isNight ? subTotal * 1.1 : subTotal;

    // Vẽ lại bảng hóa đơn
    let billBody = document.getElementById("billBody");
    billBody.innerHTML = "";

    selectedItems.forEach(item => {
        let row = `<tr>
            <td>${item.name}</td>
            <td>${item.price}</td>
        </tr>`;
        billBody.innerHTML += row;
    });

    // Nếu đi ban đêm, hiển thị dòng phụ thu 10%
    if (isNight) {
        let nightRow = `<tr style="font-style: italic; color: #d9534f;">
            <td>Phụ thu ban đêm (+10%)</td>
            <td>${Math.round(subTotal * 0.1)}</td>
        </tr>`;
        billBody.innerHTML += nightRow;
    }

    document.getElementById("totalPrice").innerText = Math.round(grandTotal) + " đồng";
    document.getElementById("billArea").style.display = "block";
}