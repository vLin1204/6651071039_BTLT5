// Ba số cho trước
let num1 = 15;
let num2 = 28;
let num3 = 9;

// Sử dụng hàm Math.max() để tìm số lớn nhất
let maxNumber = Math.max(num1, num2, num3);

// Chuỗi thông báo kết quả
let resultText = "Số lớn nhất trong 3 số (" + num1 + ", " + num2 + ", " + num3 + ") là: " + maxNumber;

// 1. Xuất ra Tab Console (F12)
console.log(resultText);

// 2. Xuất ra Hộp thoại alert
alert(resultText);

// 3. Xuất ra Giao diện trang web (Khớp id KetQua trong HTML)
document.getElementById("KetQua").innerText = resultText;