// Hàm xử lý phép Nhân (Multiply)
function multiply() {
    let num1 = parseFloat(document.getElementById("num1").value);
    let num2 = parseFloat(document.getElementById("num2").value);
    let resultElement = document.getElementById("KetQua");

    if (isNaN(num1) || isNaN(num2)) {
        resultElement.innerText = "Vui lòng nhập đầy đủ 2 số!";
        resultElement.style.color = "#dc3545";
        return;
    }

    let result = num1 * num2;
    resultElement.innerText = "Kết quả phép nhân: " + result;
    resultElement.style.color = "#198754";
}

// Hàm xử lý phép Chia (Divide)
function divide() {
    let num1 = parseFloat(document.getElementById("num1").value);
    let num2 = parseFloat(document.getElementById("num2").value);
    let resultElement = document.getElementById("KetQua");

    if (isNaN(num1) || isNaN(num2)) {
        resultElement.innerText = "Vui lòng nhập đầy đủ 2 số!";
        resultElement.style.color = "#dc3545";
        return;
    }

    if (num2 === 0) {
        resultElement.innerText = "Không thể chia cho số 0!";
        resultElement.style.color = "#dc3545";
        return;
    }

    let result = num1 / num2;
    resultElement.innerText = "Kết quả phép chia: " + result.toFixed(2);
    resultElement.style.color = "#0d6efd";
}