function tinhLuong() {
    // Lấy giá trị Lương và Hệ số lương từ các ô input
    let luong = parseFloat(document.getElementById("luong").value);
    let heSoLuong = parseFloat(document.getElementById("heSoLuong").value);
    let inputLuongThang = document.getElementById("luongThang");

    // Kiểm tra dữ liệu đầu vào
    if (isNaN(luong) || isNaN(heSoLuong)) {
        alert("Vui lòng nhập đầy đủ Lương và Hệ số lương hợp lệ!");
        return;
    }

    // Yêu cầu đề bài: Lương tháng = Lương * Hệ số lương
    let luongThang = luong * heSoLuong;

    // Gán kết quả vào ô input Lương tháng
    inputLuongThang.value = luongThang;
}