// Năm cần kiểm tra
let year = 2024;

let isLeapYear = false;

// Cấu trúc kiểm tra năm nhuận
if ((year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0)) {
    isLeapYear = true;
} else {
    isLeapYear = false;
}

// Tạo chuỗi thông báo kết quả
let resultText = isLeapYear 
    ? "Năm " + year + " LÀ năm nhuận." 
    : "Năm " + year + " KHÔNG PHẢI là năm nhuận.";

// 1. Xuất ra Tab Console (F12)
console.log(resultText);

// 2. Xuất ra Hộp thoại alert
alert(resultText);

// 3. Xuất ra Giao diện trang web
document.getElementById("KetQua").innerText = resultText;