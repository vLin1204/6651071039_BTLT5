// 1. Nhận các hệ số a, b, c từ hộp thoại Prompt
let a = parseFloat(prompt("Nhập hệ số a:"));
let b = parseFloat(prompt("Nhập hệ số b:"));
let c = parseFloat(prompt("Nhập hệ số c:"));

let resultText = "";

// Kiểm tra xem dữ liệu nhập vào có hợp lệ hay không
if (isNaN(a) || isNaN(b) || isNaN(c)) {
    resultText = "Vui lòng nhập đầy đủ các hệ số là số hợp lệ!";
} else if (a === 0) {
    // Nếu a = 0 -> Trở thành phương trình bậc nhất bx + c = 0
    if (b === 0) {
        if (c === 0) {
            resultText = "Phương trình có vô số nghiệm.";
        } else {
            resultText = "Phương trình vô nghiệm.";
        }
    } else {
        let x = -c / b;
        resultText = "Vì a = 0, đây là phương trình bậc nhất. Nghiệm x = " + x.toFixed(2);
    }
} else {
    // Phương trình bậc 2: Tính Delta = b^2 - 4ac
    let delta = b * b - 4 * a * c;

    if (delta < 0) {
        resultText = "Phương trình vô nghiệm (Delta < 0).";
    } else if (delta === 0) {
        let x = -b / (2 * a);
        resultText = "Phương trình có nghiệm kép: x1 = x2 = " + x.toFixed(2);
    } else {
        let x1 = (-b + Math.sqrt(delta)) / (2 * a);
        let x2 = (-b - Math.sqrt(delta)) / (2 * a);
        resultText = "Phương trình có 2 nghiệm phân biệt:\nx1 = " + x1.toFixed(2) + "\nx2 = " + x2.toFixed(2);
    }
}

// 2. Xuất kết quả ra hộp thoại Alert của trình duyệt
alert(resultText);

// 3. Xuất kết quả ra Console và Giao diện HTML
console.log(resultText);
document.getElementById("KetQua").innerText = resultText;