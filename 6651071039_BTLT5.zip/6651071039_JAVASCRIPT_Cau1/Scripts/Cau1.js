let a=5;
let b=6;
let c=7;

let p=(a+b+c)/2; //Chu Vi

let area=Math.sqrt(p*(p-a)*(p-b)*(p-c));

console.log("Dien tich tam giac : ",area); //In 

alert("Dien tich sau khi lay 2 chu so thap phan : "+ area.toFixed(2));

document.getElementById("KetQua").innerText="Dien tich sau khi lay 2 chu so thap phan : "+ area.toFixed(2);
