function xuatThu() {
    let ngay = parseInt(document.getElementById("ngay").value);
    let thang = parseInt(document.getElementById("thang").value);
    let nam = parseInt(document.getElementById("nam").value);
    let resultElement = document.getElementById("KetQua");

    // Kiểm tra tính hợp lệ của ngày tháng
    if (isNaN(ngay) || isNaN(thang) || isNaN(nam)) {
        resultElement.innerText = "Vui lòng nhập đầy đủ ngày, tháng, năm!";
        return;
    }

    // Tạo đối tượng Date (Lưu ý: Tháng trong JavaScript tính từ 0 - 11 nên phải trừ 1)
    let dateObj = new Date(nam, thang - 1, ngay);

    // Mảng lưu tên các thứ trong tuần
    let daysOfWeek = [
        "Chủ Nhật", 
        "Thứ 2", 
        "Thứ 3", 
        "Thứ 4", 
        "Thứ 5", 
        "Thứ 6", 
        "Thứ 7"
    ];

    // getDay() trả về số từ 0 (Chủ Nhật) đến 6 (Thứ 7)
    let dayName = daysOfWeek[dateObj.getDay()];

    // Định dạng chuỗi hiển thị đúng mẫu: "Thứ X Ngày D tháng M năm YYYY"
    let resultText = dayName + " Ngày " + ngay + " tháng " + thang + " năm " + nam;

    // Xuất kết quả lên giao diện
    resultElement.innerText = resultText;
}